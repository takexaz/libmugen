/* minimum code for playing a MP3 */
/* (looks like a lot of people want a very simple example) */

#include <allegro.h>
#include "libamp.h"

int main(void)
{
 allegro_init();
 install_sound(DIGI_AUTODETECT,MIDI_NONE,NULL);
 install_amp();
 load_amp("M:/music/mp3/renegade.mp3",FALSE);
 while (run_amp()>=0);
 unload_amp();
 return(0);
}

